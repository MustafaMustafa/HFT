// lib.cxx
// .L lib.cxx+
/*
  #include "digadc.cxx"   
  #include "digbeam.cxx"
  
  #ifdef __MAKECINT__
  #pragma link C++ class DIGADC+;
  #pragma link C++ class DIGBeam+;
  #endif
*/
// end of lib.cxx

{


}
