{
  gROOT->ProcessLine(".L digresult.cxx+");
  gROOT->ProcessLine(".L digaction.cxx+");
  gROOT->ProcessLine(".L digadc.cxx+");
  gROOT->ProcessLine(".L digbeam.cxx+");
  gROOT->ProcessLine(".L digplane.cxx+");
  gROOT->ProcessLine(".L digtransport.cxx+");
  gROOT->ProcessLine(".L digparticle.cxx+"); 
  gROOT->ProcessLine(".L digreadoutmap.cxx+");
  gROOT->ProcessLine(".L digcluster.cxx+");
  gROOT->ProcessLine(".L digevent.cxx+"); 
  gROOT->ProcessLine(".L diginitialize.cxx+");
  gROOT->ProcessLine(".L dighistograms.cxx+");
  gROOT->ProcessLine(".L digmaps.cxx+");
  //gROOT->ProcessLine(".L digproto.cxx+");
  
}
